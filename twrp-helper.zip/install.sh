on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

  if [ ${MAGISK_VER%%.*} -lt 19 ]; then
    abort 'This module requires Magisk v19 or later.'
  fi

  # Detect if device uses A/B partitioning and set target slot
  if [ -d /dev/block/bootdevice/by-name/boot_a ]; then
    active_slot=$(getprop ro.boot.slot_suffix)
    if [ "$active_slot" == "_a" ]; then
      target_slot="_b"
    else
      target_slot="_a"
    fi
    target_recovery="/dev/block/bootdevice/by-name/boot$target_slot"
    ui_print "Device is A/B, targeting $target_slot for operations"
  else
    target_recovery=$(readlink $(find /dev/block/platform -type l -iname recovery))
    ui_print "Device is not A/B, targeting standard recovery partition"
  fi
}

post_installation() {
  ui_print "- Running post-installation"

  # Depending on your actual patching logic, adapt this part
  if [ -n "$target_recovery" ]; then
    ui_print "Patching target recovery at $target_recovery"
    # Here you should add the actual patching commands
  fi

  ui_print "Installation complete. Please reboot to apply changes."
}
