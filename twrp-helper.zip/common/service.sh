#!/system/bin/sh

# Helper functions for hex conversion and patching
to_hex() {
  echo -en "$1" | xxd -pc 256 | tr -d '[ \n]'
}

hexpatch() {
  local h_from=$(to_hex "$2")
  local rpadding=$(printf '%*s' $((${#2}-${#3})))
  local h_to=$(to_hex "$3$rpadding")
  [ ! -f $1 ] && abort 4 "File to be patched, $1, does not exist."
  local output=$($mb hexpatch $1 $h_from $h_to 2>&1)
  count=$((count+1))
  if [ "${output/Patch/}" != "$output" ]; then
    echo Patch $count succeeded. >&2
    return 0
  else
    abort $((128+$count)) "Patch $count failed."
  fi
}

abort() {
  echo "$2" >&2
  exit $1
}

# Initial setup
MODDIR=${0%/*}
mydir=${MODDIR:-/data/adb/modules/twrp-helper}
log=${log:-$mydir/twrp-helper.log}
count=0
mb=/data/adb/magisk/magiskboot
store=/storage/emulated/0/Download

# Detect A/B partition scheme
if [ -d /dev/block/bootdevice/by-name/boot_a ]; then
  ab_device=true
  current_slot=$(getprop ro.boot.slot_suffix)
  [ -z "$current_slot" ] && current_slot=$(getprop ro.boot.slot) && current_slot="_$current_slot"
else
  ab_device=false
fi

# Adjust recovery handling based on A/B device
if [ "$ab_device" = true ]; then
  echo "Device uses A/B partitions. Current slot: $current_slot"
  target_slot=$([ "$current_slot" = "_a" ] && echo "_b" || echo "_a")
  recovery="/dev/block/bootdevice/by-name/boot$target_slot"
else
  recovery=$(readlink $(find /dev/block/platform -type l -iname recovery))
fi

# Backup current slot before changes
if [ "$ab_device" = true ]; then
  echo "Backing up current slot $current_slot..."
  dd if="/dev/block/bootdevice/by-name/boot$current_slot" of="$store/boot$current_slot-backup.img"
fi

# Patch operations
echo Reading recovery image from $recovery... >&2
dd if=$recovery of=twrp.img
$mb unpack twrp.img
hexpatch ramdisk.cpio "\x00/media\x00" "\x00/.twrp\x00"
$mb repack twrp.img twrp-patched.img

# Validate the new image
if [ ! -f twrp-patched.img ]; then
  echo "Failed to create patched image, restoring backup..."
  dd if="$store/boot$current_slot-backup.img" of="/dev/block/bootdevice/by-name/boot$current_slot"
  abort 3 "Failed to pack new ramdisk."
fi

# Apply the patched image to the inactive slot
echo "Writing new recovery image to $recovery..." >&2
dd if=twrp-patched.img of=$recovery bs=$(stat -c%s twrp-patched.img)

# Cleanup
rm -f twrp.img twrp-patched.img ramdisk.cpio
echo "Patching complete. Device may need a restart to apply changes."
