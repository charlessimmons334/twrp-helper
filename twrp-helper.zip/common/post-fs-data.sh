#!/system/bin/sh
MODDIR=${0%/*}

# Logging setup
LOGFILE="$MODDIR/twrp_patch.log"
echo "Starting TWRP internal storage inclusion patch." > $LOGFILE

# Function to modify TWRP backup settings
update_twrp_settings() {
  # Assume TWRP stores its settings in /data/twrp/settings.conf
  SETTINGS_FILE="/data/twrp/settings.conf"
  if [ -f $SETTINGS_FILE ]; then
    # Example: setting to include internal storage
    echo "include_internal_storage=1" >> $SETTINGS_FILE
    echo "Updated TWRP settings to include internal storage in backups." >> $LOGFILE
  else
    echo "TWRP settings file not found." >> $LOGFILE
    exit 1
  fi
}

# Execute the update function
update_twrp_settings

echo "TWRP patching complete." >> $LOGFILE
